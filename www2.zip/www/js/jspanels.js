/* 

Start with the mobile design which is full width windows in order (top to bottom)

render
graph
sensors, clock - half width each
blockly



We want the blockly area to be as big as the screen can allow

idea - hide panels until they are the right size?


*/

//extra height added to content area to prevent scrollbar appearing
var jspanelExtraHeight = 6; 
var jspanelExtraWidth = 6;

//amount to subtract from panel size to calculate content height after resize
var jspanelHeaderHeight = 29; 

/******************************************************************************


var panels = [{
	
	
	
}]

******************************************************************************/


var grid = gridpanel.createGrid(16, 9);

grid.setProperty('sizeRule','showAll');
grid.addPanel('renderPanel',0,0,8,7);
grid.addPanel('graphPanel',8,0,5,3);
grid.addPanel('blocklyPanel',8,3,8,6.5);
grid.addPanel('sensorPanel',13,0,3,3);
grid.addPanel('clockPanel',0,7,2,2);
grid.addPanel('scorePanel',2,7,2,2);
grid.addPanel('codePanel',6,7,2,2);
grid.addPanel('dataPanel',4,7,2,2);


/******************************************************************************

Create jsPanels 
 
/*****************************************************************************/
$( document ).ready(function() { 

	//grid.setPageSize(window.innerWidth, window.innerHeight);
	grid.setPageSize($(window).width(), $(window).height());

	var id = 'renderPanel'
	var dims = grid.getPanelDims(id) 
	
	var renderPanel =	jsPanel.create({
		id: id,
		maximizedMargin: 0,
		syncMargins: true,
		theme:       'primary',
		contentSize: {
			width: dims.w - jspanelExtraWidth,//function() { return renderInitialWidth},
			height: dims.h - jspanelHeaderHeight//function() { return renderInitialHeight + jspanelExtraHeight}
		},
		position:    dims.p, //'left-top 0 0',
		headerControls: "none",
		animateIn:   'jsPanelFadeIn',
		headerTitle: 'Location: 55.9231N 3.1879W; Season: summer', //TODO get from lat,lon vars
		content:     '<div id="renderPanelContent"></div>',
		onwindowresize: true
	});
  
	id = 'graphPanel'
	dims = grid.getPanelDims(id) 
	
	jsPanel.create({
		id: id,
		maximizedMargin: 0,
		syncMargins: true,
		theme:       'primary',
		contentSize: {
			width: dims.w - jspanelExtraWidth, //function() { return 405;}, 
			height: dims.h - jspanelHeaderHeight //			function() { return 185;} 
		},
		position:    dims.p, //'right-top -190 0',
		headerControls: "none",
		animateIn:   'jsPanelFadeIn',
		headerTitle: 'Graph',
		content:     '<div id="graphPanelContent"></div>',
		onwindowresize: true
	});

	id = 'clockPanel'
	dims = grid.getPanelDims(id) 
	
	var clockPanel =	jsPanel.create({
		id: id,
		maximizedMargin: 0,
		syncMargins: true,
		theme:       'primary',
		contentSize: {
			width: dims.w - jspanelExtraWidth, //function() { return 100}, 
			height: dims.h //function() { return 105} 
		},
		position:    dims.p,//'left-bottom 250 0',
		animateIn:   'jsPanelFadeIn',
		//header: 'auto-show-hide',
		headerControls: "none",
		headerTitle: 'Clock',
		content: '<div style="background-color:#333"'+
					 'id="clockPanelContent"></div>',
		onwindowresize: true,
		overflow: 'hidden',
		resizeit:{disable:true}
	});
		
	id = 'sensorPanel'	
	dims = grid.getPanelDims(id) 
	jsPanel.create({
		id: id,
		maximizedMargin: 0,
		syncMargins: true,
		maximizedMargin: 0,
		syncMargins: true,
		theme:       'primary',
		contentSize: {
			width: dims.w - jspanelExtraWidth, //function() { return 185}, 
			height: dims.h - jspanelHeaderHeight //function() { return 185} 
		},
		position:    dims.p,//'right-top 0 0',
		headerControls: "none",
		animateIn:   'jsPanelFadeIn',
		headerTitle: 'Sensors',
		content:     '<div id="sensorPanelContent"></div>',
		onwindowresize: true,
	});

    id = 'blocklyPanel'
	dims = grid.getPanelDims(id) 
	jsPanel.create({
		id: id,
		maximizedMargin: 0,
		syncMargins: true,
		theme:       'primary',
		contentSize: {
			width: dims.w - jspanelExtraWidth, //function() { return Math.min(595, window.innerWidth*0.9);},
			height: dims.h - jspanelHeaderHeight //function() { return Math.min(280, window.innerHeight*0.9);}
		},
		position:    dims.p,//'right-top 0 225',
		headerControls: "none",
		animateIn:   'jsPanelFadeIn',
		headerTitle: 'Blockly workspace',
		content:     '<div id="blocklyPanelContent"></div>',
		onwindowresize: true
	});
	
    id = 'codePanel'
	dims = grid.getPanelDims(id) 
	jsPanel.create({
			id: id,
			maximizedMargin: 0,
			syncMargins: true,
			theme:       'primary',
			contentSize: {
				width: dims.w - jspanelExtraWidth, //function() { return Math.min(400, window.innerWidth*0.9);},
				height: dims.h//function() { return Math.min(200, window.innerHeight*0.9);}
			},
			position:    dims.p,//'right-top -475 200',
			headerControls: "none",
			animateIn:   'jsPanelFadeIn',
			headerTitle: 'Blockly',
			content:     '<div id="codePanelContent"></div>',
			onwindowresize: true,
			//setStatus: "minimized"
	});

    id = 'dataPanel'
	dims = grid.getPanelDims(id) 
	jsPanel.create({
			id: id,
			maximizedMargin: 0,
			syncMargins: true,
			theme:       'primary',
			contentSize: {
				width: dims.w - jspanelExtraWidth, //function() { return Math.min(400, window.innerWidth*0.9);},
				height: dims.h//function() { return Math.min(200, window.innerHeight*0.9);}
			},
			position:    dims.p,//'right-top -475 200',
			headerControls: "none",
			animateIn:   'jsPanelFadeIn',
			headerTitle: 'File',
			content:     '<div id="dataPanelContent"></div>',
			onwindowresize: true,
			//setStatus: "minimized"
	});

    
	id = 'scorePanel'
    dims = grid.getPanelDims(id) 
	jsPanel.create({
			id: id,
			maximizedMargin: 0,
			syncMargins: true,
			theme:       'primary',
			contentSize: {
				width: dims.w - jspanelExtraWidth, //function() { return Math.min(200, window.innerWidth*0.9);},
				height: dims.h //function() { return Math.min(200, window.innerHeight*0.9);}
			},
			position:    dims.p, //'right-top -475 200',
			animateIn:   'jsPanelFadeIn',
			headerTitle: 'Efficiency',
			//header: 'auto-show-hide',
			headerControls: "none",
			content:     '<div id="scorePanelContent"></div>',
			onwindowresize: true,
			setStatus: "normalized"
	});

		
	jQuery("#renderHere").detach().appendTo('#renderPanelContent')
	jQuery("#blocklyDOM").detach().appendTo('#blocklyPanelContent')
	jQuery("#clock").detach().appendTo('#clockPanelContent')
	jQuery("#graphHere").detach().appendTo('#graphPanelContent')	
	jQuery("#sensors").detach().appendTo('#sensorPanelContent')
	jQuery("#score").detach().appendTo('#scorePanelContent')
	jQuery("#save").detach().appendTo('#codePanelContent')	
	jQuery("#data").detach().appendTo('#dataPanelContent')
		

	document.addEventListener('jspanelresize', function (event) {
		
		//get dimensions of the resized panel (0th panel in array)
		var panelHeight = parseFloat(jsPanel.getPanels()[0].style.height).toFixed(0);
		var panelWidth = parseFloat(jsPanel.getPanels()[0].style.width).toFixed(0); 
		
		//adjust for the usable area
		var contentHeight = panelHeight - jspanelHeaderHeight;
		var contentWidth  = panelWidth - jspanelExtraWidth;
		console.log(event.detail, contentWidth, contentHeight)
		if (event.detail === 'renderPanel') {resizeRender(contentHeight, contentWidth);}
		if (event.detail === 'blocklyPanel') {resizeBlockly(contentHeight, contentWidth);}
		if (event.detail === 'graphPanel') {resizeGraph(contentHeight, contentWidth);}
		if (event.detail === 'sensorPanel') {resizeSensor(contentHeight, contentWidth);}
		if (event.detail === 'scorePanel') {resizeScore(contentHeight, contentWidth);}
		

	});
	
	setTimeout(function(){ resizeContentAllPanels(); }, 100);

}); //ready


function resizeContentAllPanels(){

	for (const panel of jsPanel.getPanels()) {

			var dims = grid.getPanelDims(panel.id)
			panel.resize(dims.w, dims.h)
	        
			var panelHeight = parseFloat(panel.style.height).toFixed(0);
			var panelWidth = parseFloat(panel.style.width).toFixed(0);
			var contentHeight = panelHeight - jspanelHeaderHeight;
			var contentWidth  = panelWidth;			
			if (panel.id === 'renderPanel') {resizeRender(contentHeight, contentWidth);}
			if (panel.id === 'blocklyPanel') {resizeBlockly(contentHeight, contentWidth);}
			if (panel.id === 'graphPanel') {resizeGraph(contentHeight, contentWidth);}
			if (panel.id === 'sensorPanel') {resizeSensor(contentHeight, contentWidth);}
			if (panel.id === 'scorePanel') {resizeScore(contentHeight, contentWidth);}
			
		
			
	}
	
	
}

function resizeCanvasById(id,height, width){
	var canvas = document.getElementById(id)
	canvas.width = width;
	canvas.height = height;	
	
}

function resizeScore(height, width){
	if (scoreDial !== undefined) scoreDial.setSize(height, width);
	
}

function resizeSensor(height, width){
	resizeCanvasById('sensors', height, width);
}

function resizeGraph(height, width){
	var graphArea = document.getElementById('graphHere')
	graphArea.width = width;
	graphArea.height = height;
}

function resizeBlockly(height, width){
	var blocklyArea = document.getElementById('blocklyArea')
	blocklyArea.offsetHeight = height;
	blocklyArea.offsetWidth = width; 
	blockly_onresize();
}

function resizeRender(height, width){
	renderer.setSize( width, height);
	camera.aspect = width / height;
	camera.updateProjectionMatrix();		
}
	
