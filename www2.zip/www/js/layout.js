/*
var grid = gridpanel.createGrid(16, 9);

grid.addPanel('model',0,0,8,7);
grid.addPanel('graph',8,0,5,3);
grid.addPanel('blockly',8,3,8,6);
grid.addPanel('sensor',13,0,3,3);
grid.addPanel('clock',0,7,2,2);
grid.addPanel('score',2,7,2,2);


$( document ).ready(function() {
	
	grid.setPageSize(window.innerWidth, window.innerHeight);

	console.log(grid.getPanelDims('model'));
	console.log(grid.getPanelDims('graph'));
	console.log(grid.getPanelDims('blockly'));
	console.log(grid.getPanelDims('sensor'));
	console.log(grid.getPanelDims('clock'));
	
	
}); */