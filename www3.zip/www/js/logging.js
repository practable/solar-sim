var url = 'https://edlablog.eng.ed.ac.uk/post';
var data = JSON.stringify({"webapp":"test","who":"jstest", "when":"docready foo 2"});
var contentType = 'application/json';
var uuid = undefined;
var webappName = undefined;
var sessionCount = undefined;

/* 
 * modified from https://codepen.io/Jvsierra/pen/BNbEjW
 * random number string in uuid format
 */
function makeUuid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() 
}

/*
 * @function doNotTrack
 * @description Checks if user has declared Do Not Track (DNT) in their browser
 * Ignores IE10: Read this for further explanation: https://en.wikipedia.org/wiki/Do_Not_Track#Internet_Explorer_10_default_setting_controversy
 * @returns {*}
 */
var doNotTrack = function () {

  if (!window.navigator.userAgent.match(/MSIE\s10\.0|trident\/6\.0/i)) {
    return window.navigator.doNotTrack || window.navigator.msDoNotTrack;
  }
};


/*
 * return uuid to report our usage to
 * check in cache to see if repeat user, 
 * unless user wants session-to-session anonymity
 */
function getUuid(){
  if(doNotTrack()){
    //generate a new uuid that we'll only use for this session
    return makeUuid();
  }
  else{
    //check localStorage for an existing uuid
    var uuid = localStorage.getItem(getUuidStorageId());
 
    if (!uuid){
      uuid = makeUuid();
      localStorage.setItem( getUuidStorageId(), uuid);
    }
    return uuid;
  }
}


/*
 * returns the name of the webapp
 */
function getWebappName(){
  var name = document.getElementById("projectName").value
  if (name === undefined){
    name =  window.location.href.replace(/[^a-zA-Z0-9]/g, '');
    console.log("webapp name not defined, using", name);
  }
  return name;
}


/*
 * returns the id where we will store uuid in localStorage
 */
function getUuidStorageId(){
  return getWebappName + "_uuid";
}

/*
 * returns the id where we will store sessionCount in localStorage
 */
function getSessionCountId(){
  return getWebappName + "_sessionCount";
}

/*
 * returns the current session count
 */
function getSessionCount(){
    var sessionCount = parseInt(localStorage.getItem(getSessionCountId()),10);
    sessionCount = sessionCount + 1;
    localStorage.setItem( getSessionCountId(), sessionCount);
    return sessionCount;

}

/*
 * puts the payload in a JSON object and POSTs to logger
 */
function log(payload){
  var data = {
    "webapp": webappName,
    "uuid": uuid,
    "sessionCount": sessionCount,
    "datetime": new Date().getTime(), 
    "payload":payload
  }
  
  $.ajax({
    type: "POST",
    url: url,
    data: JSON.stringify(data),
    contentType : contentType 
  }); 
}




$( document ).ready(function() {
  webappName = getWebappName();
  sessionCount = getSessionCount();
  uuid = getUuid(); 
  console.log("uuid",uuid, "sessionCount", sessionCount)
  log({"event":"logging", "value":"ready"})

});



/*

  console.log('trying ajax post')
  $.ajax({
    type: "POST",
    url: url,
    data: data,
    contentType : contentType 
  });
*/
